
package javaapplication10;
public class UserData {
    	private String username = "";
	private String password = "";
	public String getUser() {
		return username;
	}
	public String getPassword() {
		return password;
	}
	

}
